python3 apiteste.py
