import numpy as np
import os
from flask import Flask, jsonify, render_template
from flask_swagger import swagger


app = Flask(__name__, template_folder='templates_pages')



@app.route("/spec")
def spec():
    return jsonify(swagger(app))


@app.route("/")
def home():
    return render_template('home.html')

@app.route("/segundo_endpoint")
def segundo_endpoint():
    return ("Já criamos 2 funções", 200)

if __name__ == "__main__":
    debug = True #com essa opção habilitada ao salvar o site recarrega automaticamente
    app.run(host='0.0.0.0', port=8080, debug=debug)
